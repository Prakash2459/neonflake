// Get references to the input fields and buttons
const urlInput = document.getElementById('url');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const saveButton = document.getElementById('saveButton');
const viewButton = document.getElementById('viewButton');
const credentialsList = document.getElementById('credentialsList');

// Save data to Chrome storage
saveButton.addEventListener('click', () => {
  const url = urlInput.value;
  const username = usernameInput.value;
  const password = passwordInput.value;

  if (url && username && password) {
    // Generate a unique key for each credential (e.g., URL + username)
    const key = `${url}-${username}`;

    // Save the data to Chrome's storage
    chrome.storage.sync.set({ [key]: { url, username, password } }, () => {
      console.log('Data saved!');
      alert('Credentials saved successfully!');
      urlInput.value = '';
      usernameInput.value = '';
      passwordInput.value = '';
    });
  } else {
    alert('Please fill in all fields.');
  }
});

// View saved credentials
viewButton.addEventListener('click', () => {
  // Clear the credentials list
  credentialsList.innerHTML = '';

  // Retrieve all saved credentials from Chrome storage
  chrome.storage.sync.get(null, (data) => {
    if (Object.keys(data).length === 0) {
      credentialsList.innerHTML = '<p>No credentials saved yet.</p>';
    } else {
      for (const key in data) {
        const credential = data[key];
        const credentialItem = document.createElement('div');
        credentialItem.className = 'credential-item';
        credentialItem.innerHTML = `
          <strong>URL:</strong> ${credential.url}<br>
          <strong>Username:</strong> ${credential.username}<br>
          <strong>Password:</strong> ${credential.password}
          <button class="deleteButton" data-key="${key}">Delete</button>
        `;
        credentialsList.appendChild(credentialItem);
      }
    }
  });
});
credentialsList.addEventListener('click', (event) => {
    if (event.target.classList.contains('deleteButton')) {
      const key = event.target.getAttribute('data-key');
      chrome.storage.sync.remove(key, () => {
        console.log('Credential deleted!');
        event.target.parentElement.remove(); // Remove the credential item from the list
      });
    }
  });
// Load saved data when the popup opens (optional)
window.addEventListener('load', () => {
  // You can load specific credentials here if needed
});